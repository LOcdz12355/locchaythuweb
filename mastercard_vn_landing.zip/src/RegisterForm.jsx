
import React from 'react';

const RegisterForm = () => (
    <section className="py-16 px-6 bg-white text-center">
        <h2 className="text-4xl font-bold text-gray-800 mb-8">📨 Đăng Ký Nhận Ưu Đãi</h2>
        <form className="space-y-6 max-w-md mx-auto">
            <input type="text" placeholder="Họ và Tên" required className="w-full p-3 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-500" />
            <input type="email" placeholder="Email" required className="w-full p-3 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-500" />
            <input type="tel" placeholder="Số điện thoại" required className="w-full p-3 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-500" />
            <button type="submit" className="w-full bg-orange-500 text-white p-3 rounded-full font-semibold hover:bg-orange-600 transition">Hoàn Tất Đăng Ký</button>
        </form>
    </section>
);

export default RegisterForm;
