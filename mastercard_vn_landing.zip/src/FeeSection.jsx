
import React from 'react';

const FeeCard = ({ image, title, description, button }) => (
    <div className="bg-white p-8 rounded-2xl shadow-lg text-center hover:scale-105 transition transform duration-300">
        <img src={image} alt={title} className="mx-auto mb-6 h-40 object-contain" />
        <h3 className="text-2xl font-semibold mb-4">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        <button className="bg-orange-500 text-white px-6 py-3 rounded-full font-semibold hover:bg-orange-600 transition">{button}</button>
    </div>
);

const FeeSection = () => (
    <section className="py-16 px-6 bg-gray-100">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-800">📋 Biểu Phí Thẻ Mastercard VN</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <FeeCard 
                image="https://assets-global.website-files.com/60df6ab859f9f8e8bbf822a7/61f9401c6eeb85787e2f45d8_Credit-Card-3D.png" 
                title="Phí Phát Hành Thẻ" 
                description="Ưu đãi đặc biệt - Không lo chi phí năm đầu" 
                button="Đăng Ký Ngay" />
            <FeeCard 
                image="https://assets-global.website-files.com/60df6ab859f9f8e8bbf822a7/61f93f6e227b85c6808a94cf_Calendar-3D.png" 
                title="Phí Thường Niên" 
                description="300.000 VNĐ/năm. Miễn phí năm đầu." 
                button="Tìm Hiểu Thêm" />
            <FeeCard 
                image="https://assets-global.website-files.com/60df6ab859f9f8e8bbf822a7/61f93ec54614aa6c81d4be03_Cash-3D.png" 
                title="Phí Rút Tiền Mặt" 
                description="4% số tiền giao dịch. (Tối thiểu 50.000 VNĐ)" 
                button="Chi Tiết" />
        </div>
    </section>
);

export default FeeSection;
