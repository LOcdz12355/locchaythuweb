
import React from 'react';

const HeroSection = () => (
    <section className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white py-20 text-center">
        <h1 className="text-5xl font-bold mb-4">Thẻ Mastercard VN</h1>
        <p className="text-lg mb-8">Trải nghiệm tự do tài chính, ưu đãi hấp dẫn ngay hôm nay!</p>
        <button className="bg-white text-orange-500 font-bold px-8 py-3 rounded-full hover:bg-gray-100 transition">Đăng Ký Ngay</button>
    </section>
);

export default HeroSection;
