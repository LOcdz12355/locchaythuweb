
import React from 'react';
import HeroSection from './HeroSection';
import FeeSection from './FeeSection';
import RegisterForm from './RegisterForm';
import Footer from './Footer';

const App = () => {
    return (
        <div>
            <HeroSection />
            <FeeSection />
            <RegisterForm />
            <Footer />
        </div>
    );
};

export default App;
