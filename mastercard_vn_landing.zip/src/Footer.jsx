
import React from 'react';

const Footer = () => (
    <footer className="bg-gray-800 text-white py-8 text-center">
        <h3 className="text-2xl font-semibold mb-4">Bạn đã sẵn sàng sở hữu thẻ Mastercard VN?</h3>
        <a href="#" className="bg-orange-500 text-white px-8 py-3 rounded-full font-bold text-lg hover:bg-orange-600 transition">
            Đăng Ký Ngay Hôm Nay
        </a>
        <p className="mt-4 text-gray-400 text-sm">© 2025 Thẻ Mastercard VN. All rights reserved.</p>
    </footer>
);

export default Footer;
